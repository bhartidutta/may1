from django.apps import AppConfig


class ModeldConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'modeld'
