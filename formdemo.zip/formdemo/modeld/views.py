from django.shortcuts import render

# Create your views here.
def modeld(request):
    return render(request,'model.html')