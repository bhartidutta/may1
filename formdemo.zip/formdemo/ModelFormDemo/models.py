from django.db import models
class Employee(models.Model):
    ename=models.CharField(max_length=20)
    email=models.EmailField()
    class Meta:
        db_table="Employee"

# Create your models here.
