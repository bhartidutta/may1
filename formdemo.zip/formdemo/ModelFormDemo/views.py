from django.shortcuts import render
from .forms import Emp
from .models import Employee

# Create your views here.
def modeldemo(request):
    fm=Emp()
    return render(request,"modeldemo.html",{'form':fm})
